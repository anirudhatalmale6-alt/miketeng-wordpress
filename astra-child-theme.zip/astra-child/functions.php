<?php
/**
 * Astra Child Theme - Dr Michael Teng
 */

// Enqueue parent + child styles
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('astra-parent', get_template_directory_uri() . '/style.css');
    wp_enqueue_style('astra-child', get_stylesheet_uri(), ['astra-parent'], '1.0');
});

// Add scroll animation script
add_action('wp_footer', function() {
?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Scroll reveal
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, { threshold: 0.1, rootMargin: '0px 0px -60px 0px' });

    document.querySelectorAll('.fade-in').forEach(el => observer.observe(el));

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
});
</script>
<?php
});

// Remove Astra default page title for custom pages
add_filter('astra_the_title_enabled', function($enabled) {
    if (is_page()) return false;
    return $enabled;
});

// Add custom body classes
add_filter('body_class', function($classes) {
    $classes[] = 'miketeng-site';
    return $classes;
});

// Disable Gutenberg default styles to avoid conflicts
add_action('wp_enqueue_scripts', function() {
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('wp-block-library-theme');
}, 100);
